package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class FriendList {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int friendListId;
	private String friendName;
	@ManyToOne
	private UserProfile user;
	
	public FriendList() {}

	public FriendList(String friendName, UserProfile user) {
		super();
		this.friendName = friendName;
		this.user = user;
	}

	public FriendList(String friendName) {
		super();
		this.friendName = friendName;
	}

	public int getFriendListId() {
		return friendListId;
	}

	public void setFriendListId(int friendListId) {
		this.friendListId = friendListId;
	}

	public String getFriendName() {
		return friendName;
	}

	public void setFriendName(String friendName) {
		this.friendName = friendName;
	}

	public UserProfile getUser() {
		return user;
	}

	public void setUser(UserProfile user) {
		this.user = user;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + friendListId;
		result = prime * result + ((friendName == null) ? 0 : friendName.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FriendList other = (FriendList) obj;
		if (friendListId != other.friendListId)
			return false;
		if (friendName == null) {
			if (other.friendName != null)
				return false;
		} else if (!friendName.equals(other.friendName))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "FriendList [friendListId=" + friendListId + ", friendName=" + friendName + "]";
	}

	
	
}
