package com.cg.capbook.beans;
import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class Likes {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int likeId;
	private int likedBy;
	private LocalDateTime dateOfLike;
	@ManyToOne
	private Post post;

	public Likes() {}

	public Likes(int likedBy, LocalDateTime dateOfLike, Post post) {
		super();
		this.likedBy = likedBy;
		this.dateOfLike = dateOfLike;
		this.post = post;
	}

	public Likes(int likedBy, LocalDateTime dateOfLike) {
		super();
		this.likedBy = likedBy;
		this.dateOfLike = dateOfLike;
	}

	public int getLikeId() {
		return likeId;
	}

	public void setLikeId(int likeId) {
		this.likeId = likeId;
	}

	public int getLikedBy() {
		return likedBy;
	}

	public void setLikedBy(int likedBy) {
		this.likedBy = likedBy;
	}

	public LocalDateTime getDateOfLike() {
		return dateOfLike;
	}

	public void setDateOfLike(LocalDateTime dateOfLike) {
		this.dateOfLike = dateOfLike;
	}

	public Post getpost() {
		return post;
	}

	public void setpost(Post post) {
		this.post = post;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dateOfLike == null) ? 0 : dateOfLike.hashCode());
		result = prime * result + likeId;
		result = prime * result + likedBy;
		result = prime * result + ((post == null) ? 0 : post.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Likes other = (Likes) obj;
		if (dateOfLike == null) {
			if (other.dateOfLike != null)
				return false;
		} else if (!dateOfLike.equals(other.dateOfLike))
			return false;
		if (likeId != other.likeId)
			return false;
		if (likedBy != other.likedBy)
			return false;
		if (post == null) {
			if (other.post != null)
				return false;
		} else if (!post.equals(other.post))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Like [likeId=" + likeId + ", likedBy=" + likedBy + ", dateOfLike=" + dateOfLike + "]";
	}

}
