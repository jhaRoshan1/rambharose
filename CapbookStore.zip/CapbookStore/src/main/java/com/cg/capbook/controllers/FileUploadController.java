package com.cg.capbook.controllers;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.cg.capbook.beans.Image;
import com.cg.capbook.beans.UserProfile;
import com.cg.capbook.exceptions.FileStorageException;
import com.cg.capbook.services.ImageServices;
import com.cg.capbook.services.StorageService;
import com.cg.capbook.services.UserProfileServices;
@Controller
@SessionAttributes("user")
public class FileUploadController {
	private final StorageService storageService;
    private static final Logger logger = LoggerFactory.getLogger(FileUploadController.class);
	@Autowired
	ImageServices imageServices;
	@Autowired
	UserProfileServices userProfileServices;
	@Autowired
	public FileUploadController(StorageService storageService) {
		this.storageService = storageService;
	}

	@RequestMapping("/uploadProfilePic")
	public ModelAndView uploadProfileFile(@SessionAttribute("user") UserProfile user,@RequestParam("file") MultipartFile file,RedirectAttributes redirectAttributes) throws FileStorageException {
		String fileName = storageService.store(file);
		String albumName="profile";
		String imageURL = ServletUriComponentsBuilder.fromCurrentContextPath()
				.path("/downloadFile/")
				.path(fileName)
				.toUriString();
		
		Image image =new Image(LocalDateTime.now(), fileName,  file.getContentType(), file.getSize(), albumName, imageURL, user); 
		imageServices.saveImage(image);
		user=userProfileServices.getUserProfileDetails(user.getUserId());
		
		return new ModelAndView("dashboard", "user", user);

	}

	/*
	 * @PostMapping("/uploadFile") public void
	 * uploadFile(@SessionAttribute("user")UserProfile user,@RequestParam("file")
	 * MultipartFile file,String albumName) { String fileName =
	 * storageService.store(file); String imageURL =
	 * ServletUriComponentsBuilder.fromCurrentContextPath() .path("/downloadFile/")
	 * .path(fileName) .toUriString(); Image image =new Image(LocalDateTime.now(),
	 * fileName, file.getContentType(), file.getSize(), albumName, imageURL, user);
	 * imageServices.saveImage(image);
	 * user=userProfileServices.getUserProfileDetails(user.getUserId()); }
	 */

	/*
	 * @PostMapping("/uploadMultipleFiles") public ModelAndView
	 * uploadMultipleFiles(@SessionAttribute("user")UserProfile
	 * user,@RequestParam("files") MultipartFile[] files,String albumName) {
	 * albumName="default"; for (int i = 0; i < files.length; i++) { MultipartFile
	 * multipartFile = files[i]; uploadFile(user, multipartFile, albumName); }
	 * return new ModelAndView("dashboard", "user", user); }
	 */

	@GetMapping("/downloadFile/{fileName:.+}")
	public ResponseEntity<Resource> downloadFile(@PathVariable String fileName, HttpServletRequest request) {
		// Load file as Resource
		Resource resource =storageService.loadFileAsResource(fileName);

		// Try to determine file's content type
		String contentType = null;
		try {
			contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
		} catch (IOException ex) {
			logger.info("Could not determine file type.");
		}

		// Fallback to the default content type if type could not be determined
		if(contentType == null) {
			contentType = "application/octet-stream";
		}

		return ResponseEntity.ok()
				.contentType(MediaType.parseMediaType(contentType))
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
				.body(resource);
	}
}

