package com.cg.capbook.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capbook.beans.ForumRequest;

public interface ForumRequestDao extends JpaRepository<ForumRequest, Integer>{

}
