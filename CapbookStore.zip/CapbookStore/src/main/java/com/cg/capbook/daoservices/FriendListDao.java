package com.cg.capbook.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capbook.beans.FriendList;

public interface FriendListDao extends JpaRepository<FriendList, Integer> {

}
