package com.cg.capbook.daoservices;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.capbook.beans.Image;
@Repository
@Transactional
public interface ImageDao extends JpaRepository<Image, Integer> {
	@Query(value="from Image i where i.user.userId=:userId and i.fileName=:name")
	Image getImageByName(@Param("name") String imageName,@Param("userId") Integer userId);
}
