package com.cg.capbook.daoservices;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.capbook.beans.UserProfile;
@Repository
@Transactional
public interface UserProfileDao extends JpaRepository<UserProfile, Integer>{
	@Query("from UserProfile u where u.emailId=:email")
	UserProfile findByEmailId(@Param("email") String emailId);

}
