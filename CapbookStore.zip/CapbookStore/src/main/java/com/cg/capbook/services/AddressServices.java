package com.cg.capbook.services;

import com.cg.capbook.beans.Address;

public interface AddressServices {
	Address acceptAddressDetails(int userId,Address address);
	Address getAddressDetails(int userId);
	boolean updateAddressDetails(int userId,Address address);
	boolean deleteAddressDetails(int userId);
}
