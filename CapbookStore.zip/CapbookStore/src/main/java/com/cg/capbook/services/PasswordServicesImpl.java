package com.cg.capbook.services;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.UserProfile;
import com.cg.capbook.exceptions.InvalidCurrentPasswordException;
import com.cg.capbook.exceptions.InvalidSecurityAnswerException;
import com.cg.capbook.exceptions.UserProfileNotFoundException;
@Component("passwordServices")
public class PasswordServicesImpl implements PasswordServices{
	@Autowired
	UserProfileServices userProfileServices;
	/*@Override
	public String forgotUserPassword(String emailId,String securityQuestion,String securityAnswer)throws UserProfileNotFoundException,InvalidSecurityAnswerException {
		UserProfile user=userProfileServices.getUserProfileDetailsByEmail(emailId);
		if(user.getSecurityQuestion().equalsIgnoreCase(securityQuestion)&&user.getSecurityAnswer().equalsIgnoreCase(securityAnswer))
		return user.getPassword();
		else 
			throw new InvalidSecurityAnswerException("InvalidSecurityAnswer!!");
	}

	@Override
	public boolean changeUserPassword(int userId, String newPassword,String currentPassword) throws InvalidCurrentPasswordException{
		UserProfile user=userProfileServices.getUserProfileDetails(userId);
		if(user.getPassword().equals(currentPassword)==false)
			throw new InvalidCurrentPasswordException("Invalid Current password Entered");
		else {
			user.setPassword(newPassword);
			userProfileServices.updateUserProfileDetails(user);
		}
		return true;
	}

}
*/
	
	private Base64 base64 = new Base64();
	@Override
	public String forgotUserPassword(String emailId,String securityQuestion,String securityAnswer)throws UserProfileNotFoundException,InvalidSecurityAnswerException {
		UserProfile user=userProfileServices.getUserProfileDetailsByEmail(emailId);
		if(user.getSecurityQuestion().equalsIgnoreCase(securityQuestion)&&user.getSecurityAnswer().equalsIgnoreCase(securityAnswer))
		{
			String decodedString = new String(base64.decode(user.getPassword().getBytes()));	
			return decodedString;
		}
		else 
			throw new InvalidSecurityAnswerException("InvalidSecurityAnswer!!");
	}

	@Override
	public boolean changeUserPassword(int userId, String newPassword,String currentPassword) throws InvalidCurrentPasswordException{
		UserProfile user=userProfileServices.getUserProfileDetails(userId);
		String decodedString = new String(base64.decode(user.getPassword().getBytes()));
		if(decodedString.equals(currentPassword)==false)
			throw new InvalidCurrentPasswordException("Invalid Current password Entered");
		else {
			String encodedString = new String(base64.encode(newPassword.getBytes()));
			user.setPassword(encodedString);
			userProfileServices.updateUserProfileDetails(user);
		}
		return true;
	}

}